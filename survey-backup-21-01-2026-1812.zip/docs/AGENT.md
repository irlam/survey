# AGENT.md

This file documents the actions and decisions made by the coding agent for the survey PDF editor project.

- All milestones are implemented in order, with small commits and evidence links in docs/milestones.md.
- See prompt.txt for full requirements and rules.
