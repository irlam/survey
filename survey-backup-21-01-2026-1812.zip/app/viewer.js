// app/viewer.js
// DEBUG: Top-level script execution log and counter
window.__viewerDebugCounter = (window.__viewerDebugCounter || 0) + 1;
console.log('[DEBUG] viewer.js loaded, counter:', window.__viewerDebugCounter);
// DEBUG: Add a floating debug div to show tempPins live
function showTempPinsDebug() {
  let dbg = document.getElementById('tempPinsDebug');
  if (!dbg) {
    dbg = document.createElement('div');
    dbg.id = 'tempPinsDebug';
    dbg.style.position = 'fixed';
    dbg.style.bottom = '10px';
    dbg.style.right = '10px';
    dbg.style.background = 'rgba(255,255,0,0.95)';
    dbg.style.color = '#000';
    dbg.style.zIndex = 99999;
    dbg.style.fontSize = '12px';
    dbg.style.padding = '8px';
    dbg.style.border = '2px solid #f00';
    dbg.style.maxWidth = '400px';
    dbg.style.maxHeight = '200px';
    dbg.style.overflow = 'auto';
    document.body.appendChild(dbg);
  }
  dbg.textContent = '[DEBUG] tempPins: ' + JSON.stringify(tempPins);
}
// PDF.js viewer + overlay layer + Add Issue Mode (pins only, no DB save yet)

let pdfDoc = null;
let currentPage = 1;
let totalPages = 0;

let userZoom = 1.0;
let fitScale = 1.0;
let fitMode = true;

let addIssueMode = false;
let tempPins = []; // {page, x_norm, y_norm, label}

function qs(sel) { return document.querySelector(sel); }

function getPlanIdFromUrl() {
  const u = new URL(window.location.href);
  const v = u.searchParams.get('plan_id');
  const n = parseInt(v || '0', 10);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function setStatus(text) {
  const el = qs('#viewerMsg');
  if (el) el.textContent = text || '';
}

function setTitle(text) {
  const el = qs('#planTitle');
  if (el) el.textContent = text || 'Plan';
}

function setModeBadge() {
  const b = qs('#modeBadge');
  if (!b) return;
  // Show badge when Add Issue mode is ON
  b.style.display = addIssueMode ? 'inline-flex' : 'none';
  console.log('setModeBadge: addIssueMode', addIssueMode, 'badge display:', b.style.display);
}

function setBadges() {
  const pageBadge = qs('#pageBadge');
  if (pageBadge) pageBadge.textContent = totalPages ? `Page ${currentPage} / ${totalPages}` : 'Page - / -';

  const pageInput = qs('#pageInput');
  if (pageInput && totalPages) pageInput.value = String(currentPage);

  const zoomBadge = qs('#zoomBadge');
  if (zoomBadge) zoomBadge.textContent = `${Math.round(userZoom * 100)}%`;
}

function ensurePdfJsConfigured() {
  if (!window.pdfjsLib) throw new Error('PDF.js not loaded. Check /vendor/pdfjs/pdf.min.js');
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.js';
}

function stageWidth() {
  const stage = qs('#pdfStage');
  if (!stage) return window.innerWidth;
  return Math.max(320, stage.clientWidth - 16);
}

function ensureWrapAndOverlay() {
  console.log('DEBUG: ensureWrapAndOverlay called');
  const container = qs('#pdfContainer');
  if (!container) throw new Error('Missing #pdfContainer');

  let wrap = container.querySelector('.pdfWrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.className = 'pdfWrap';
    container.innerHTML = '';
    container.appendChild(wrap);
  }

  let canvas = wrap.querySelector('canvas');
  if (!canvas) {
    canvas = document.createElement('canvas');
    canvas.id = 'pdfCanvas';
    wrap.appendChild(canvas);
  }

  let overlay = wrap.querySelector('.pdfOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.className = 'pdfOverlay';
    wrap.appendChild(overlay);
    console.log('DEBUG: .pdfOverlay created and added to DOM', overlay);
    // Attach pointerdown event directly to overlay
    overlay.addEventListener('pointerdown', async (e) => {
      console.log('DEBUG: pointerdown event fired on overlay', e);
      if (!addIssueMode) return;

      // Only accept taps that happen on the overlay itself (or its children)
      if (!overlay.contains(e.target)) return;

      // Get overlay and canvas bounds
      const overlayRect = overlay.getBoundingClientRect();
      const canvas = overlay.parentElement.querySelector('canvas');
      if (!canvas) return;
      const canvasRect = canvas.getBoundingClientRect();

      // Check if click is within canvas bounds (visible PDF)
      if (
        e.clientX < canvasRect.left ||
        e.clientX > canvasRect.right ||
        e.clientY < canvasRect.top ||
        e.clientY > canvasRect.bottom
      ) {
        console.log('Click outside visible PDF area, not adding pin');
        // Extra guard: do not update pin label, do not push to tempPins, do not update UI
        return;
      }

      // Only proceed if inside canvas
      // Calculate normalized coordinates relative to overlay
      const x = e.clientX - overlayRect.left;
      const y = e.clientY - overlayRect.top;
      const w = overlayRect.width;
      const h = overlayRect.height;
      if (w <= 0 || h <= 0) return;

      const x_norm = Math.max(0, Math.min(1, x / w));
      const y_norm = Math.max(0, Math.min(1, y / h));

      // Only increment label and push pin if inside canvas
      const label = String(tempPins.filter(p => p.page === currentPage).length + 1);
      tempPins.push({ page: currentPage, x_norm, y_norm, label });
  console.log('[DEBUG] tempPins after push:', JSON.stringify(tempPins));
  showTempPinsDebug();

      await renderPage(currentPage);
    }, { capture: true });
  }

  // Always enable hit-testing based on latest addIssueMode
  overlay.style.pointerEvents = addIssueMode ? 'auto' : 'none';

  return { wrap, canvas, overlay };
}

async function apiGetPlan(planId) {
  const res = await fetch(`/api/get_plan.php?plan_id=${encodeURIComponent(planId)}`, { credentials: 'same-origin' });
  const txt = await res.text();
  let data;
  try { data = JSON.parse(txt); } catch { throw new Error(`get_plan invalid JSON: ${txt}`); }
  if (!res.ok || !data.ok) throw new Error(data.error || `get_plan failed: HTTP ${res.status}`);
  return data;
}

async function loadPdf(pdfUrl) {
  ensurePdfJsConfigured();
  setStatus('Loading PDF…');

  const task = window.pdfjsLib.getDocument({ url: pdfUrl, withCredentials: true });
  pdfDoc = await task.promise;

  totalPages = pdfDoc.numPages;
  currentPage = 1;

  setStatus('');
  setBadges();
}

function clearOverlay(overlay) {
  overlay.innerHTML = '';
}

function renderPinsForPage(overlay, viewportWidth, viewportHeight) {
  clearOverlay(overlay);

  const pins = tempPins.filter(p => p.page === currentPage);
  console.log('[DEBUG] renderPinsForPage:', {
    overlay,
    overlayWidth: overlay.offsetWidth,
    overlayHeight: overlay.offsetHeight,
    viewportWidth,
    viewportHeight,
    pinsCount: pins.length,
    pins
  });
  for (const p of pins) {
    const el = document.createElement('div');
    el.className = 'pin';
    el.textContent = p.label;
    el.style.left = `${p.x_norm * viewportWidth}px`;
    el.style.top = `${p.y_norm * viewportHeight}px`;
    overlay.appendChild(el);
    console.log(`[DEBUG] Pin label ${p.label} at (x_norm: ${p.x_norm}, y_norm: ${p.y_norm}) => (left: ${p.x_norm * viewportWidth}px, top: ${p.y_norm * viewportHeight}px)`);
    console.log('[DEBUG] Pin element appended:', el, 'at', el.style.left, el.style.top);
  }
  showTempPinsDebug();
}

async function renderPage(pageNo) {
  console.log('DEBUG: renderPage called for page', pageNo);
  if (!pdfDoc) return;

  const { wrap, canvas, overlay } = ensureWrapAndOverlay();
  const ctx = canvas.getContext('2d');

  setStatus(`Rendering page ${pageNo}…`);
  const page = await pdfDoc.getPage(pageNo);

  const w = stageWidth();
  const v1 = page.getViewport({ scale: 1.0 });
  fitScale = w / v1.width;

  const effectiveScale = fitMode ? (fitScale * userZoom) : userZoom;
  const viewport = page.getViewport({ scale: effectiveScale });

  // HiDPI
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.floor(viewport.width * dpr);
  canvas.height = Math.floor(viewport.height * dpr);
  canvas.style.width = `${Math.floor(viewport.width)}px`;
  canvas.style.height = `${Math.floor(viewport.height)}px`;

  // Wrap/overlay must match CSS pixel size
  wrap.style.width = `${Math.floor(viewport.width)}px`;
  wrap.style.height = `${Math.floor(viewport.height)}px`;
  overlay.style.width = `${Math.floor(viewport.width)}px`;
  overlay.style.height = `${Math.floor(viewport.height)}px`;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  await page.render({ canvasContext: ctx, viewport }).promise;

  renderPinsForPage(overlay, Math.floor(viewport.width), Math.floor(viewport.height));

  setStatus('');
  setBadges();
  setModeBadge();
}

async function goToPage(n) {
  if (!pdfDoc) return;
  const pageNo = Math.max(1, Math.min(totalPages, n));
  currentPage = pageNo;
  await renderPage(currentPage);
}

function bindUiOnce() {
  if (window.__viewerBound) return;
  window.__viewerBound = true;

  const prevBtn = qs('#btnPrev');
  const nextBtn = qs('#btnNext');
  const goBtn = qs('#btnGo');
  const pageInput = qs('#pageInput');
  const zoomOut = qs('#btnZoomOut');
  const zoomIn = qs('#btnZoomIn');
  const fitBtn = qs('#btnFit');
  const closeBtn = qs('#btnCloseViewer');
  const addBtn = qs('#btnAddIssueMode');

  if (prevBtn) prevBtn.onclick = () => goToPage(currentPage - 1);
  if (nextBtn) nextBtn.onclick = () => goToPage(currentPage + 1);

  if (goBtn) {
    goBtn.onclick = () => {
      const v = parseInt(pageInput ? pageInput.value : '1', 10);
      goToPage(Number.isFinite(v) ? v : 1);
    };
  }
  if (pageInput) {
    pageInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const v = parseInt(pageInput.value || '1', 10);
        goToPage(Number.isFinite(v) ? v : 1);
      }
    });
  }

  if (zoomOut) zoomOut.onclick = async () => { userZoom = Math.max(0.25, userZoom - 0.25); await renderPage(currentPage); };
  if (zoomIn) zoomIn.onclick = async () => { userZoom = Math.min(5.0, userZoom + 0.25); await renderPage(currentPage); };
  if (fitBtn) fitBtn.onclick = async () => { fitMode = true; userZoom = 1.0; await renderPage(currentPage); };

  if (addBtn) {
    addBtn.onclick = async () => {
      addIssueMode = !addIssueMode;
      addBtn.textContent = addIssueMode ? 'Done' : 'Add Issue';
      setModeBadge();
      // Re-render so overlay matches the current canvas size and pins redraw, and pointer-events is set correctly
      if (pdfDoc) await renderPage(currentPage);
    };
  }

  // ...pointerdown now handled directly on overlay...

  if (closeBtn) {
    closeBtn.onclick = () => {
      const u = new URL(window.location.href);
      u.searchParams.delete('plan_id');
      history.pushState({}, '', u.pathname);

      setTitle('Select a plan');
      setStatus('');

      const c = qs('#pdfContainer');
      if (c) c.innerHTML = '';

      pdfDoc = null;
      totalPages = 0;
      currentPage = 1;
      userZoom = 1.0;

      addIssueMode = false;
      setModeBadge();
      setBadges();

      document.body.classList.remove('has-viewer');
    };
  }

  window.addEventListener('resize', () => {
    if (pdfDoc) renderPage(currentPage);
  });
}

// Public: open a plan from the sidebar button
export async function openPlanInApp(planId) {
  const u = new URL(window.location.href);
  u.searchParams.set('plan_id', String(planId));
  history.pushState({}, '', u.toString());
  await startViewer();
}

// Public: start viewer based on current URL plan_id
export async function startViewer() {
  bindUiOnce();

  const planId = getPlanIdFromUrl();
  if (!planId) {
    setTitle('Select a plan');
    setStatus('');
    setBadges();
    return;
  }

  document.body.classList.add('has-viewer');

  try {
    const data = await apiGetPlan(planId);
    const plan = data.plan || {};
    const pdfUrl = data.pdf_url || plan.pdf_url || `/api/plan_file.php?plan_id=${planId}`;

    setTitle(plan.name || `Plan ${planId}`);

    fitMode = true;
    userZoom = 1.0;

    await loadPdf(pdfUrl);
    await renderPage(1);
  } catch (e) {
    console.error(e);
    setStatus(e.message || 'Viewer error');
  }
}
