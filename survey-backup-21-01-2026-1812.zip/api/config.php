<?php
return [
  'base_url' => 'https://survey.defecttracker.uk',
  'storage_path' => 'storage',

  'db' => [
    'host' => '10.35.233.124',
    'port' => 3306,
    'dbname' => 'k87747_survey',
    'user' => 'k87747_defecttracker',
    'pass' => 'Subaru5554346',
    'charset' => 'utf8mb4',
  ],
];
