<?php
return [
    'base_url' => '', // e.g. https://survey.defecttracker.uk
    'db_host' => 'localhost',
    'db_name' => '',
    'db_user' => '',
    'db_pass' => '',
    'db_charset' => 'utf8mb4',
    'storage_path' => '../storage',
    'max_upload_mb' => 25,
    'actor_name' => '' // optional, for audit
];
